class CustomError{
  String title;
  String details;

  CustomError(this.title, this.details);
}