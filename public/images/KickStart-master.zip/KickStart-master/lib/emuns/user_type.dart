enum UserType{
  Registered,
  Anonymous
}